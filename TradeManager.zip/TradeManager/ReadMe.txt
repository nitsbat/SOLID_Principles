Exchange is the Main  class and also an abstract class.

Trade is the class for creating the trade.

Exchange class is the base class which is extending three child cases based on the exchange type - BSE,LME,CMe. Based on Exchange type the classes are defined, and
the CalculateFees function are define which is an abstract method in the Exchange.