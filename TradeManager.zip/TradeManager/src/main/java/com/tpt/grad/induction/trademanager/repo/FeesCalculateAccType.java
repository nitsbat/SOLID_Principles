package com.tpt.grad.induction.trademanager.repo;

import com.tpt.grad.induction.trademanager.model.Trade;

public interface FeesCalculateAccType {
	
	public Long calFees(Trade t);
	
}
