package com.tpt.grad.induction.trademanager.model;

public enum Account_Type {
	Elite, Prime, Regular;
}
