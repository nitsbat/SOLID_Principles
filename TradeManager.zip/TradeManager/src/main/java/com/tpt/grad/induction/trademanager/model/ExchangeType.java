package com.tpt.grad.induction.trademanager.model;

public enum ExchangeType {
	BSE,CME,LME;
}
